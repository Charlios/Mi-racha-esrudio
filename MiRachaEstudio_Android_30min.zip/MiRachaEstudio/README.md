# Mi Racha de Estudio (Android) — objetivo de 30 minutos

Aplicación Android local basada en una página HTML integrada en un WebView. El objetivo diario está configurado en 30 minutos. No requiere permiso de Internet y conserva el progreso en el almacenamiento local de la aplicación.

## Generar el APK
1. Instala Android Studio en un ordenador.
2. Abre la carpeta `MiRachaEstudio` como proyecto.
3. Deja que Gradle sincronice y descargue el Android SDK que solicite (compileSdk 35).
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. El APK de depuración aparecerá normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar
Copia el APK al móvil Android y ábrelo. Puede que Android te pida permitir la instalación desde esa fuente.

La app no solicita permisos de red. Los datos permanecen en el almacenamiento privado de la app; desinstalarla o borrar sus datos puede eliminarlos.
